jQuery('document').ready(function($) {	
setTimeout(function(){
$('body').addClass('load');
}, 3000);
});